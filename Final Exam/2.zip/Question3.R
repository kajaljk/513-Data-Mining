#################################################
#  Purpose    : Final Exam Question 3
#  First Name : Kajal
#  Last Name  : Khunt
#  Id			    : 10429885
#################################################

rm(list = ls())

## Load the dataset
dsn <- read.csv("D:\\MS\\Spring 2018\\CS-513\\Assignment\\Final Exam\\IBM_Employee_Attrition_V2.csv")
dsn<- na.omit(dsn)

library(class) 
library(e1071)

## Naive Bayes

index<-sort(sample(nrow(dsn),round(.30*nrow(dsn))))
training<-dsn[-index,]
test<-dsn[index,]

nBayes_bc2 <- naiveBayes(Attrition ~., data =training)
category_all<-predict(nBayes_bc2,test)

# calculating error rate
table(NBayes=category_all,Attrition=test$Attrition)
NB_wrong<-sum(category_all!=test$Attrition )
NB_error_rate<-NB_wrong/length(category_all)
NB_error_rate


## Random Forest
library(randomForest)

fit <- randomForest(Attrition ~., data=training, importance=TRUE, ntree=100)
importance(fit)
varImpPlot(fit)
Prediction <- predict(fit, test)
table(actual=test$Attrition ,Prediction)

# calculating error rate
wrong<- (test$Attrition!=Prediction )
error_rate<-sum(wrong)/length(wrong)
error_rate 


## CART
library(rpart)
library(rpart.plot)
library(rattle)
library(RColorBrewer)

CART<-rpart(Attrition ~. ,data=training,method="class",control =rpart.control(minsplit=2000,minbucket=1, cp=0))
printcp(CART) # display the results
#plotcp(CART_class_1) # visualize cross-validation results
summary(CART) # detailed summary of splits

# plot tree
rpart.plot(CART)
prp(CART)

# calculating error rate
CART_predict<-predict(CART,test, type="class")
CART_wrong<-sum(test[,2]!=CART_predict)
CART_error_rate<-CART_wrong/length(test[,2])
CART_error_rate
accuracy<-(1-CART_error_rate)*100


# C50   
library('C50')
C50_class <- C5.0( Attrition~.,data=training )

summary(C50_class )
dev.off()
plot(C50_class)
C50_predict<-predict( C50_class ,test , type="class" )
table(actual=test[,2],C50=C50_predict)
wrong<- (test[,2]!=C50_predict)
c50_rate<-sum(wrong)/length(test[,2])
c50_rate


